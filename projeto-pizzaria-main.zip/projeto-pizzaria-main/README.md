# projeto-pizzaria
Projeto da Pizzaria Bel Piatto
Trabalho NUP 2, Professor Daniel Gomes (descendente do caneta azul, azul caneta)
Feito por: Amanda, Ben, Cayc e Leticia
